<?php $__env->startSection('content'); ?>
    <h1>Create Product</h1>

    <form method="POST" action="<?php echo e(route('product.store')); ?>">
        <?php echo csrf_field(); ?>

        <label>Code:</label>
        <input type="text" name="code" required>

        <label>Name:</label>
        <input type="text" name="name" required>

        <label>Description:</label>
        <textarea name="description"></textarea>

        <label>Purchase Price:</label>
        <input type="number" name="purchase_price" step="0.01" required>

        <label>Selling Price:</label>
        <input type="number" name="selling_price" step="0.01" required>

        <label>Category Code:</label>
        <input type="text" name="category_code">

        <label>Model Label:</label>
        <input type="text" name="model_label">

        <label>Max Height:</label>
        <input type="number" name="max_height">

        <label>Composition:</label>
        <input type="text" name="composition">

        <button type="submit">Add Product</button>
    </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Applications/MAMP/htdocs/poslovanje_app/poslovanje_app/resources/views/product/create.blade.php ENDPATH**/ ?>