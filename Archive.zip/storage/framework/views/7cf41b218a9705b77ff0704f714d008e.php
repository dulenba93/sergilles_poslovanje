<div class="mb-3">
    <label>Šifra</label>
    <input type="text" name="sifra" class="form-control" value="<?php echo e(old('sifra', $product['sifra'] ?? '')); ?>">
</div>

<div class="mb-3">
    <label>Naziv</label>
    <input type="text" name="naziv" class="form-control" value="<?php echo e(old('naziv', $product['naziv'] ?? '')); ?>">
</div>

<div class="mb-3">
    <label>Opis</label>
    <textarea name="opis" class="form-control"><?php echo e(old('opis', $product['opis'] ?? '')); ?></textarea>
</div>

<div class="mb-3">
    <label>Nabavna cena</label>
    <input type="number" name="nabavna_cena" class="form-control" step="0.01" value="<?php echo e(old('nabavna_cena', $product['nabavna_cena'] ?? '')); ?>">
</div>

<div class="mb-3">
    <label>Prodajna cena</label>
    <input type="number" name="prodajna_cena" class="form-control" step="0.01" value="<?php echo e(old('prodajna_cena', $product['prodajna_cena'] ?? '')); ?>">
</div>

<div class="mb-3">
    <label>Šifra kategorije</label>
    <input type="text" name="sifra_kategorije" class="form-control" value="<?php echo e(old('sifra_kategorije', $product['sifra_kategorije'] ?? '')); ?>">
</div>

<div class="mb-3">
    <label>Oznaka modela</label>
    <input type="text" name="oznaka_modela" class="form-control" value="<?php echo e(old('oznaka_modela', $product['oznaka_modela'] ?? '')); ?>">
</div>

<div class="mb-3">
    <label>Maksimalna visina</label>
    <input type="number" name="max_visina" class="form-control" step="0.1" value="<?php echo e(old('max_visina', $product['max_visina'] ?? '')); ?>">
</div>

<div class="mb-3">
    <label>Sastav</label>
    <input type="text" name="sastav" class="form-control" value="<?php echo e(old('sastav', $product['sastav'] ?? '')); ?>">
</div>
<?php /**PATH /Applications/MAMP/htdocs/poslovanje_app/poslovanje_app/resources/views/product/form.blade.php ENDPATH**/ ?>