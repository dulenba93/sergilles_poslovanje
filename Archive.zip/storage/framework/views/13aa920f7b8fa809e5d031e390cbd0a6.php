<?php $__env->startSection('content'); ?>
    <div class="container mx-auto px-4">
        <h1 class="text-2xl font-semibold mb-4">Proizvodi</h1>
        <a href="<?php echo e(route('products.create')); ?>" class="bg-blue-500 text-white px-4 py-2 rounded mb-4 inline-block">Dodaj novi proizvod</a>

        <div class="bg-white shadow rounded-lg p-6">
            <table class="min-w-full table-auto border-collapse">
                <thead>
                    <tr>
                        <th class="border-b py-2 text-left">Naziv</th>
                        <th class="border-b py-2 text-left">Šifra</th>
                        <th class="border-b py-2 text-left">Cena</th>
                        <th class="border-b py-2 text-left">Akcije</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id => $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td class="py-2 border-b"><?php echo e($product['naziv'] ?? ''); ?></td>
                            <td class="py-2 border-b"><?php echo e($product['sifra'] ?? ''); ?></td>
                            <td class="py-2 border-b"><?php echo e($product['prodajna_cena'] ?? ''); ?> RSD</td>
                            <td class="py-2 border-b">
                                <a href="<?php echo e(route('products.edit', $id)); ?>" class="text-blue-600">Izmeni</a> |
                                <form action="<?php echo e(route('products.destroy', $id)); ?>" method="POST" class="inline">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                    <button type="submit" class="text-red-600">Obriši</button>
                                </form>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.dashboard', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Applications/MAMP/htdocs/poslovanje_app/poslovanje_app/resources/views/product/index.blade.php ENDPATH**/ ?>