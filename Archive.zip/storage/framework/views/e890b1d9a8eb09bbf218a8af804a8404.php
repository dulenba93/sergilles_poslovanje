<style>
    /* Smanji širinu sidebar-a */
    .fi-sidebar {
        width: 250px !important;
    }

    .fi-main {
        margin-left: 4px !important;
    }
</style>
<?php /**PATH /Applications/MAMP/htdocs/poslovanje_app/poslovanje_app/resources/views/filament/custom-styles.blade.php ENDPATH**/ ?>