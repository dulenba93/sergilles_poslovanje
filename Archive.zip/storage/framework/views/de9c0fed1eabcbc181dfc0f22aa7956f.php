<div class="space-y-6">
    <div class="text-lg font-bold">Radni nalog #<?php echo e($record->code); ?></div>
<div style="display: grid; grid-template-columns: repeat(3, 1fr); gap: 1rem;">
    <div><strong>Ime kupca:</strong> <?php echo e($record->customer_name); ?></div>
    <div><strong>Telefon:</strong> <?php echo e($record->phone); ?></div>
    <div><strong>Email:</strong> <?php echo e($record->email ?? '-'); ?></div>

    <div><strong>Tip plaćanja:</strong> <?php echo e($record->tip_placanja); ?></div>
    <div><strong>Status:</strong> <?php echo e($record->status); ?></div>
    <div><strong>Zakazano:</strong>
        <?php echo e($record->scheduled_at ? \Carbon\Carbon::parse($record->scheduled_at)->format('d.m.Y H:i') : '-'); ?>

    </div>

    <div><strong>Ukupna cena:</strong> <?php echo e(number_format($record->total_price, 2, ',', '.')); ?> RSD</div>
    <div><strong>Avans:</strong> <?php echo e(number_format($record->advance_payment, 2, ',', '.')); ?> RSD</div>
    <div><strong>Preostalo za naplatu:</strong> 
        <?php echo e(number_format($record->total_price - $record->advance_payment, 2, ',', '.')); ?> RSD
    </div>
</div>

    <div>
        <strong>Napomena:</strong><br>
        <div class=""><?php echo e($record->note ?? '—'); ?></div>
    </div>
    <hr>
<!--[if BLOCK]><![endif]--><?php if($record->positions && $record->positions->count()): ?>
    <div>
        <h3 class="text-lg font-bold mb-2">Pozicije</h3>

        <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $record->positions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $pozicija): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php
                $type = $pozicija->pozicija_type;
                $model = null;

                if ($type === 'metraza') {
                    $model = \App\Models\PozicijaMetraza::find($pozicija->pozicija_id);
                } elseif ($type === 'garnisna') {
                    $model = \App\Models\PozicijaGarnisna::find($pozicija->pozicija_id);
                }

                $product = $model?->product;
            ?>

            <!--[if BLOCK]><![endif]--><?php if($model): ?>
                <div class="mb-4 border border-gray-200 rounded p-4">
                    <div class="font-semibold mb-2">
                     <?php echo e($index + 1); ?> -> <?php echo e($model->name ?? 'Bez naziva'); ?> (<?php echo e(strtoupper($type)); ?>)
                    </div>

                    <ul class="list-disc list-inside text-sm text-gray-800 space-y-1">
                                   <!--[if BLOCK]><![endif]--><?php if($product): ?>
                            <li><strong>Proizvod:</strong> <?php echo e($product->name); ?>  <?php echo e($product->opis); ?></li>
                        <?php else: ?>
                            <li><strong>Proizvod:</strong> Nepoznat</li>
                        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                        <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $model->getAttributes(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if(in_array($key, ['id', 'created_at', 'updated_at', 'product_id','name'])) continue; ?>
                            <li>
                                <strong><?php echo e(ucfirst(str_replace('_', ' ', $key))); ?>:</strong> <?php echo e($value); ?>

                            </li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->

             
                    </ul>
                </div>
            <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
    </div>
<?php else: ?>
    <p class="text-gray-500 italic">Nema dodatih pozicija za ovaj nalog.</p>
<?php endif; ?><!--[if ENDBLOCK]><![endif]-->

    <div class="flex gap-2">
        <?php if (isset($component)) { $__componentOriginal6330f08526bbb3ce2a0da37da512a11f = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal6330f08526bbb3ce2a0da37da512a11f = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'filament::components.button.index','data' => ['color' => 'gray']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('filament::button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['color' => 'gray']); ?>Pošalji potvrdu <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal6330f08526bbb3ce2a0da37da512a11f)): ?>
<?php $attributes = $__attributesOriginal6330f08526bbb3ce2a0da37da512a11f; ?>
<?php unset($__attributesOriginal6330f08526bbb3ce2a0da37da512a11f); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal6330f08526bbb3ce2a0da37da512a11f)): ?>
<?php $component = $__componentOriginal6330f08526bbb3ce2a0da37da512a11f; ?>
<?php unset($__componentOriginal6330f08526bbb3ce2a0da37da512a11f); ?>
<?php endif; ?>
        <?php if (isset($component)) { $__componentOriginal6330f08526bbb3ce2a0da37da512a11f = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal6330f08526bbb3ce2a0da37da512a11f = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'filament::components.button.index','data' => ['color' => 'success']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('filament::button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['color' => 'success']); ?>Sačuvaj nalog <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal6330f08526bbb3ce2a0da37da512a11f)): ?>
<?php $attributes = $__attributesOriginal6330f08526bbb3ce2a0da37da512a11f; ?>
<?php unset($__attributesOriginal6330f08526bbb3ce2a0da37da512a11f); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal6330f08526bbb3ce2a0da37da512a11f)): ?>
<?php $component = $__componentOriginal6330f08526bbb3ce2a0da37da512a11f; ?>
<?php unset($__componentOriginal6330f08526bbb3ce2a0da37da512a11f); ?>
<?php endif; ?>
        <?php if (isset($component)) { $__componentOriginal6330f08526bbb3ce2a0da37da512a11f = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal6330f08526bbb3ce2a0da37da512a11f = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'filament::components.button.index','data' => ['color' => 'info']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('filament::button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['color' => 'info']); ?>Pogledaj pozicije <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal6330f08526bbb3ce2a0da37da512a11f)): ?>
<?php $attributes = $__attributesOriginal6330f08526bbb3ce2a0da37da512a11f; ?>
<?php unset($__attributesOriginal6330f08526bbb3ce2a0da37da512a11f); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal6330f08526bbb3ce2a0da37da512a11f)): ?>
<?php $component = $__componentOriginal6330f08526bbb3ce2a0da37da512a11f; ?>
<?php unset($__componentOriginal6330f08526bbb3ce2a0da37da512a11f); ?>
<?php endif; ?>
    </div>
</div>
<?php /**PATH /Applications/MAMP/htdocs/poslovanje_app/poslovanje_app/resources/views/filament/resources/work-order-resource/partials/expand-row.blade.php ENDPATH**/ ?>