<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Zavese Admin Panel</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
</head>
<body>
    <div class="container-fluid">
        <div class="row">
            <aside class="col-md-3 bg-light p-4">
                <h2 class="mb-4">Zavese Admin</h2>
                <ul class="nav flex-column">
                    <li class="nav-item"><a href="<?php echo e(url('/products')); ?>" class="nav-link">Proizvodi</a></li>
                    
                </ul>
            </aside>
            <main class="col-md-9 p-4">
                <?php echo $__env->yieldContent('content'); ?>
            </main>
        </div>
    </div>
</body>
</html>
<?php /**PATH /Applications/MAMP/htdocs/poslovanje_app/poslovanje_app/resources/views/layouts/app.blade.php ENDPATH**/ ?>