<x-filament::page>
    <h2 class="text-2xl font-bold mb-6">Dobrodošli u admin panel</h2>

    <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
        <x-filament::card>
            <p class="text-lg font-medium">Ukupan broj porudžbina: [prikaz kasnije]</p>
        </x-filament::card>

        <x-filament::card>
            <p class="text-lg font-medium">Mesečni trošak: [grafika kasnije]</p>
        </x-filament::card>
    </div>
</x-filament::page>
